export default function App() {
  return (
    <div style={{ padding: 30 }}>
      <h1>Sales Tracker Dashboard</h1>

      <div className="card">
        <h2>Welcome 👋</h2>
        <p>Your dashboard is now running from GitHub Pages.</p>
      </div>
    </div>
  );
}